CREATE PROCEDURE get_biblio_cls_ancestor_ids(IN currentRowID VARCHAR(100), OUT ancestorIDs VARCHAR(1000))
  BEGIN
    DECLARE varParentID VARCHAR(100);
    DECLARE varParentsAncestorIDs VARCHAR(1000);
    SELECT parent_id INTO varParentID FROM sys_biblio_classification WHERE id = currentRowID;
    IF varParentID = "0"
      THEN SET ancestorIDs = varParentID;
    ELSE
      CALL get_biblio_cls_ancestor_ids(varParentID, varParentsAncestorIDs);
      SET ancestorIDs = CONCAT(varParentsAncestorIDs,",",varParentID);
    END IF;
  END;
