CREATE PROCEDURE update_biblio_cls_ancestor_ids(IN currentRowID VARCHAR(100))
  BEGIN
    DECLARE ancestorIDs VARCHAR(1000);
    CALL get_biblio_cls_ancestor_ids(currentRowID, ancestorIDs);
    UPDATE sys_biblio_classification SET ancestor_ids = ancestorIDs WHERE id = currentRowID;
  END;
