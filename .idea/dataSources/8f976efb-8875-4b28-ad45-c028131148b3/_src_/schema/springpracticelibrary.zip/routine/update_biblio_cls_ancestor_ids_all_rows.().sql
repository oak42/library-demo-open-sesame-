CREATE PROCEDURE update_biblio_cls_ancestor_ids_all_rows()
  BEGIN
    DECLARE currentRowID VARCHAR(100);
    DECLARE exitFlag BOOLEAN DEFAULT FALSE;
    DECLARE curID CURSOR FOR SELECT id FROM sys_biblio_classification;
    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET exitFlag = TRUE;
    OPEN curID;
    update_loop: LOOP
      FETCH curID INTO currentRowID;
      IF exitFlag THEN LEAVE update_loop;END IF;
      CALL update_biblio_cls_ancestor_ids(currentRowID);
    END LOOP;
  END;
